from app.api.v1.schemas import Instrument

users = {}
instruments = [Instrument(name="ToyCoin", ticker="TOY")]
orderbooks = {}
transactions = {}
balances = {}
orders = {}